#!/usr/bin/env python3
from pathlib import Path
import argparse
import json
import os

COLOR = {
    'OK': '\033[92m',
    'WARN': '\033[93m',
    'ERR': '\033[91m',
    'INFO': '\033[94m',
    'END': '\033[0m'
}

def color(text, level):
    return f"{COLOR.get(level, '')}{text}{COLOR['END']}"

def cargar_configuracion(ruta="config/modelos.json"):
    try:
        with open(ruta, "r") as f:
            return json.load(f)
    except Exception as e:
        print(color(f"[ERROR] No se pudo leer la configuración: {e}", "ERR"))
        return {}

def verificar_modelo(path_modelo, min_size_mb=5):
    path = Path(path_modelo).expanduser().resolve()
    if not path.exists():
        return "❌ NO ENCONTRADO"
    if path.stat().st_size < min_size_mb * 1024 * 1024:
        return "⚠️ VACÍO/CORRUPTO"
    return "✅ OK"

def analizar_modelos(data):
    resultados = []
    for servicio, modelos in data.items():
        print(f"\n🔎 Servicio: {color(servicio, 'INFO')}")
        for modelo in modelos:
            nombre = modelo.get("nombre", "¿sin nombre?")
            ruta = modelo.get("ruta", "")
            estado = verificar_modelo(ruta)
            resultados.append((servicio, nombre, ruta, estado))
            estado_color = 'OK' if "OK" in estado else 'ERR' if "NO" in estado else 'WARN'
            print(f"  {color(estado, estado_color)} - {nombre} ({ruta})")
    return resultados

def main():
    parser = argparse.ArgumentParser(description="Diagnóstico de modelos IA")
    parser.add_argument("--config", default="config/modelos.json", help="Archivo JSON con info de modelos")
    args = parser.parse_args()

    data = cargar_configuracion(args.config)
    if not data:
        print(color("❌ No hay datos de modelos.", "ERR"))
        return

    resultados = analizar_modelos(data)
    faltantes = [r for r in resultados if "NO ENCONTRADO" in r[3]]
    corruptos = [r for r in resultados if "VACÍO" in r[3]]

    print(f"\n📊 {color(str(len(resultados)), 'INFO')} modelos analizados")
    print(f"❌ Faltantes: {color(str(len(faltantes)), 'ERR')}")
    print(f"⚠️ Posibles corruptos: {color(str(len(corruptos)), 'WARN')}")

if __name__ == "__main__":
    main()

