#!/bin/bash
set -euo pipefail

echo "📁 Accediendo a carpeta services/"
cd "$(dirname "$0")/../services"

# Definimos los módulos que se moverán y sus carpetas destino reales
declare -A modules=(
  [animatediff]="../imagen/animatediff"
  [stable-diffusion]="../imagen/stable-diffusion"
  [comfyui]="../imagen/comfyui"
  [musicgen]="../musica/musicgen"
  [stableaudio]="../musica/stableaudio"
  [xtts-es]="../voz/xtts-es"
  [memgpt]="../memoria/memgpt"
)

for name in "${!modules[@]}"; do
  target="${modules[$name]}"
  echo -e "\n🔄 Procesando módulo: $name → $target"

  # Si existe como carpeta física en services/ y no es enlace
  if [ -d "$name" ] && [ ! -L "$name" ]; then
    echo "📦 Módulo físico detectado en services/$name"

    # Crear carpeta destino si no existe
    mkdir -p "$target"
    echo "📂 Carpeta destino creada (si no existía): $target"

    # Mover el contenido a la carpeta destino
    mv "$name"/* "$target"/
    rmdir "$name"
    echo "✅ Contenido movido a $target"
  fi

  # Crear enlace simbólico en services/
  if [ ! -L "$name" ]; then
    ln -s "$target" "$name"
    echo "🔗 Enlace simbólico creado: $name → $target"
  else
    echo "✔️  Enlace ya existente: $name"
  fi
done

echo -e "\n✅ Todos los módulos han sido procesados correctamente."
