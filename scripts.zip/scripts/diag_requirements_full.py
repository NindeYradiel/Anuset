#!/usr/bin/env python3
import importlib.util
import importlib.metadata
from pathlib import Path
import argparse
import re

COLOR = {
    'OK': '\033[92m',
    'WARN': '\033[93m',
    'ERR': '\033[91m',
    'END': '\033[0m'
}

def color(text, level):
    return f"{COLOR.get(level, '')}{text}{COLOR['END']}"

def extraer_paquetes(req_path):
    paquetes = []
    try:
        for line in req_path.read_text().splitlines():
            line = line.strip()
            if not line or line.startswith("#"): continue
            match = re.match(r'^([a-zA-Z0-9_.-]+)', line)
            if match:
                paquetes.append(match.group(1))
            else:
                print(color(f"  ⚠️ Línea ignorada en {req_path.name}: {line}", 'WARN'))
    except Exception as e:
        print(color(f"[ERROR] No se pudo leer {req_path}: {e}", "ERR"))
    return paquetes

def verificar_paquete(pkg):
    try:
        importlib.metadata.version(pkg)
        return True
    except importlib.metadata.PackageNotFoundError:
        return False
    except Exception:
        return False

def analizar_servicio(req_path):
    servicio = req_path.parent.name
    paquetes = extraer_paquetes(req_path)
    faltantes = []

    print(f"\n🔍 Servicio: {color(servicio, 'OK')} ({len(paquetes)} paquetes)")

    for pkg in paquetes:
        if verificar_paquete(pkg):
            print(f"  ✅ {pkg}")
        else:
            print(color(f"  ❌ {pkg} no instalado", 'ERR'))
            faltantes.append(pkg)

    return len(faltantes)

def main():
    parser = argparse.ArgumentParser(description="Verificación profunda de requirements.txt")
    parser.add_argument("--path", default=".", help="Ruta base del proyecto")
    args = parser.parse_args()

    base = Path(args.path).resolve()
    req_files = list(base.rglob("requirements.txt"))

    print(f"📋 Encontrados: {len(req_files)} archivos")

    total_faltantes = 0
    for req in req_files:
        faltantes = analizar_servicio(req)
        total_faltantes += faltantes

    print(f"\n📊 Total paquetes faltantes: {color(str(total_faltantes), 'ERR' if total_faltantes else 'OK')}")

if __name__ == "__main__":
    main()
