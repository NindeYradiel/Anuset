#!/bin/bash
set -euo pipefail

echo "🧼 Forzando push completo de Anuset..."

# 1. Mostrar resumen
echo "📁 Estado del repo:"
git status -s

# 2. Asegurar que los directorios clave no están ignorados
echo "🔍 Validando .gitignore..."
for dir in frontend backend scripts; do
  if grep -q "^$dir/" .gitignore; then
    echo "⚠️  $dir está ignorado en .gitignore. Quitando..."
    sed -i "/^$dir\//d" .gitignore
  fi
done

# 3. Asegurar que scripts tienen permisos
echo "🔓 Asignando permisos a scripts..."
chmod +x scripts/*.sh || true
chmod +x services/*/*.sh || true

# 4. Añadir todos los cambios, incluso nuevos archivos
echo "➕ Añadiendo todo..."
git add -A

# 5. Commit de actualización forzada
echo "📝 Commit de forzado completo..."
git commit -m "🔁 push forzado: scripts, frontend, backend y configuración limpia"

# 6. Push forzado a main
echo "🚀 Subiendo con push forzado..."
git push origin main --force

echo "✅ Listo. Todo subido a main."

