#!/bin/bash
set -euo pipefail

echo "🔧 Corrigiendo permisos de scripts y servicios..."

BASE_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"

# Scripts generales
find "$BASE_DIR/scripts" -type f -name "*.sh" -exec chmod +x {} \;
echo "✔️ Permisos corregidos en scripts/"

# Scripts dentro de cada servicio
find "$BASE_DIR/services" -type f -name "*.sh" -exec chmod +x {} \;
echo "✔️ Permisos corregidos en services/*"

# Entrypoint universal
chmod +x "$BASE_DIR/scripts/entrypoint.sh"
echo "✔️ Permisos corregidos en entrypoint.sh"

echo "✅ Permisos generales corregidos con éxito."

