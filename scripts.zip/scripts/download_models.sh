#!/usr/bin/env bash
set -euo pipefail

# 📁 Configuración
MODELS_DIR="${HOME}/Modelos"
FORCE=false
DOCKER_IMAGE_ROCM="rocm/pytorch:rocm6.0-ubuntu22.04"
DOCKER_IMAGE_NVIDIA="nvidia/cuda:12.2.0-runtime-ubuntu22.04"
DOCKER_IMAGE_CPU="python:3.10-slim"
DOCKER_MODEL_DIR="/models"

# 🔁 Parseo de argumentos
[[ "${1:-}" == "--force" ]] && FORCE=true && echo "🔁 Forzando re-descarga de modelos"

# 📂 Crear carpeta destino
mkdir -p "$MODELS_DIR"

# 📥 Función de descarga
descargar_modelo() {
  local nombre="$1" url="$2" destino="$3"
  echo "📥 [$nombre] → $destino"
  if [[ "$FORCE" = true && -e "$destino" ]]; then
    echo "⚠️ [$nombre] Eliminando archivo existente"
    rm -rf "$destino"
  fi
  if [[ -e "$destino" ]]; then
    echo "✅ [$nombre] Ya existe"
  else
    mkdir -p "$(dirname "$destino")"
    if [[ "$url" == *.git ]]; then
      git clone --depth=1 "$url" "$destino"
    else
      wget -c -q --show-progress -O "$destino" "$url"
    fi
    echo "🎉 [$nombre] Descargado correctamente"
  fi
}

# 📚 Lista de modelos
descargar_modelo "codellama" \
  "https://huggingface.co/TheBloke/CodeLlama-7B-Instruct-GGUF/resolve/main/codellama-7b-instruct.Q4_K_M.gguf" \
  "${MODELS_DIR}/codellama/codellama-7b-instruct.Q4_K_M.gguf"
descargar_modelo "whisper" \
  "https://huggingface.co/openai/whisper-small/resolve/main/ggml-small.bin" \
  "${MODELS_DIR}/whisper/ggml-small.bin"
descargar_modelo "fast-whisper" \
  "https://huggingface.co/Systran/faster-whisper-small/resolve/main/model.bin" \
  "${MODELS_DIR}/fast-whisper/model.bin"
descargar_modelo "deepseek" \
  "https://huggingface.co/deepseek-ai/deepseek-coder-6.7b-instruct/resolve/main/ggml-model-q4_0.bin" \
  "${MODELS_DIR}/deepseek/ggml-model-q4_0.bin"
descargar_modelo "comfyui" \
  "https://github.com/comfyanonymous/ComfyUI.git" \
  "${MODELS_DIR}/comfyui"
descargar_modelo "animatediff" \
  "https://github.com/guoyww/AnimateDiff.git" \
  "${MODELS_DIR}/animatediff"

echo -e "\n✅ Todos los modelos procesados"

# 🐳 Configuración de entorno Docker
echo "📦 Preparando entornos Docker..."

# Dockerfile para AMD ROCm
cat <<EOF > Dockerfile.rocm
FROM ${DOCKER_IMAGE_ROCM}
RUN apt-get update && apt-get install -y wget git python3-pip && \
    python3 -m pip install --no-cache-dir torch torchvision torchaudio --extra-index-url https://download.pytorch.org/whl/rocm5.6 && \
    python3 -m pip install --no-cache-dir huggingface_hub transformers
WORKDIR ${DOCKER_MODEL_DIR}
COPY . ${DOCKER_MODEL_DIR}
EOF

# Dockerfile para NVIDIA CUDA
cat <<EOF > Dockerfile.nvidia
FROM ${DOCKER_IMAGE_NVIDIA}
RUN apt-get update && apt-get install -y wget git python3-pip && \
    python3 -m pip install --no-cache-dir torch torchvision torchaudio --extra-index-url https://download.pytorch.org/whl/cu122 && \
    python3 -m pip install --no-cache-dir huggingface_hub transformers
WORKDIR ${DOCKER_MODEL_DIR}
COPY . ${DOCKER_MODEL_DIR}
EOF

# Dockerfile para CPU
cat <<EOF > Dockerfile.cpu
FROM ${DOCKER_IMAGE_CPU}
RUN apt-get update && apt-get install -y wget git && \
    python3 -m pip install --no-cache-dir torch torchvision torchaudio --index-url https://download.pytorch.org/whl/cpu && \
    python3 -m pip install --no-cache-dir huggingface_hub transformers
WORKDIR ${DOCKER_MODEL_DIR}
COPY . ${DOCKER_MODEL_DIR}
EOF

# Construir imágenes
echo -e "\n⚙️ Construyendo imágenes Docker..."
docker build -t ai-models-rocm -f Dockerfile.rocm .
docker build -t ai-models-nvidia -f Dockerfile.nvidia .
docker build -t ai-models-cpu -f Dockerfile.cpu .

# 🚀 Instrucciones de ejecución
echo -e "\n🚀 Instrucciones para ejecutar contenedores:"
echo "🔹 AMD ROCm:"
echo "docker run --device /dev/kfd --device /dev/dri --group-add video -v ${MODELS_DIR}:${DOCKER_MODEL_DIR} -it ai-models-rocm bash"
echo "🔹 NVIDIA CUDA:"
echo "docker run --gpus all -v ${MODELS_DIR}:${DOCKER_MODEL_DIR} -it ai-models-nvidia bash"
echo "🔹 CPU:"
echo "docker run -v ${MODELS_DIR}:${DOCKER_MODEL_DIR} -it ai-models-cpu bash"