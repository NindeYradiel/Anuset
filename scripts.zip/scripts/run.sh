#!/bin/bash
set -euo pipefail

# Colores ANSI
PURPLE='\033[1;35m'
CYAN='\033[1;36m'
RESET='\033[0m'

clear
echo -e "${PURPLE}"
echo "╭────────────────── 🌙 𝒜𝓃𝓊𝓈𝑒𝓉 𝒢𝓇𝒾𝓂𝑜𝓇𝒾𝑜 ──────────────────╮"
echo "│                                                    🜁                       🜂"
echo "│     Proyecto: Anuset-FINAL                         🌠  Versión: 1.0"
echo "│     Camino: ~/Anuset/                              ✦  Autora: Kali ♡"
echo "│     Modo: Ritual Cute-Místico                      📜  Lenguaje: Bash & Make"
echo "╰────────────────────────────────────────────────────╯"
echo -e "${RESET}"

echo -e "${CYAN}"
echo "🜃 ¿Qué deseas invocar hoy, viajera estelar?"
echo "╭────────────── ✦ ✧ ✦ ─────────────╮"
echo "│ 1. 🔮 Iniciar servicios IA        │"
echo "│ 2. 🧿 Diagnóstico completo        │"
echo "│ 3. ♻️  Reiniciar rituales         │"
echo "│ 4. 🚪 Salir del círculo           │"
echo "╰──────────────────────────────────╯"
echo -e "${RESET}"

read -p "Selecciona una opción mística [1-4]: " opcion

case $opcion in
  1)
    echo -e "${PURPLE}🌐 Invocando servicios...${RESET}"
    make generar && make lanzar
    ;;
  2)
    echo -e "${PURPLE}🔍 Realizando diagnóstico...${RESET}"
    make salud
    ;;
  3)
    echo -e "${PURPLE}🌀 Reiniciando el ciclo mágico...${RESET}"
    make reiniciar
    ;;
  4)
    echo -e "${PURPLE}🌒 Cerrando el círculo ritual. Hasta luego, viajera.${RESET}"
    exit 0
    ;;
  *)
    echo -e "${CYAN}⚠️  Opción no válida. Elige sabiamente.${RESET}"
    ;;
esac
