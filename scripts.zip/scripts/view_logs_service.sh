#!/bin/bash
set -euo pipefail

SERVICE="${SERVICE:-}"
LINES="${LINES:-7}"
FOLLOW="${1:-}"

if [[ -z "$SERVICE" ]]; then
    echo -e "\033[1;31m❌ Debes definir SERVICE=nombre antes de ejecutar este script\033[0m"
    exit 1
fi

echo "📜 Logs del servicio: \033[1;34m$SERVICE\033[0m (últimas ${LINES} líneas)"
[ "$FOLLOW" == "--follow" ] && echo "🔁 Modo seguimiento activado"

# Función para colorear líneas
colorize_line() {
    local line="$1"
    if [[ "$line" == *"ERROR"* ]]; then
        echo -e "\033[0;31m$line\033[0m"
    elif [[ "$line" == *"WARNING"* ]]; then
        echo -e "\033[0;33m$line\033[0m"
    elif [[ "$line" == *"INFO"* ]]; then
        echo -e "\033[0;36m$line\033[0m"
    elif [[ "$line" == *"DEBUG"* ]]; then
        echo -e "\033[0;35m$line\033[0m"
    else
        echo "$line"
    fi
}

# Buscar el contenedor correspondiente (por coincidencia parcial)
container=$(docker ps --format '{{.Names}}' | grep -i "$SERVICE" | head -n1 || true)

if [[ -z "$container" ]]; then
    echo -e "\033[1;31m❌ No se encontró contenedor activo con nombre que contenga: $SERVICE\033[0m"
    exit 1
fi

# Mostrar logs
if [ "$FOLLOW" == "--follow" ]; then
    docker logs -f "$container" 2>&1 | while read -r line; do
        colorize_line "$line"
    done
else
    docker logs --tail "$LINES" "$container" 2>&1 | while read -r line; do
        colorize_line "$line"
    done
fi

