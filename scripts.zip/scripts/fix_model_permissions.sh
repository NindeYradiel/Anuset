#!/bin/bash
set -euo pipefail

echo "🔧 Corrigiendo permisos de modelos IA..."

# Ruta base relativa desde la raíz del proyecto
BASE_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
MODELS_DIR_1="${BASE_DIR}/Anuset/models"
MODELS_DIR_2="${BASE_DIR}/Anuset-FINAL/models"

found=false
for dir in "$MODELS_DIR_1" "$MODELS_DIR_2"; do
    if [ -d "$dir" ]; then
        echo "✔️ Corrigiendo permisos en: $dir"
        chmod -R u+rwX "$dir"
        found=true
    else
        echo "⚠️ Directorio no encontrado: $dir"
    fi
done

if [ "$found" = false ]; then
    echo "❌ No se encontraron carpetas de modelos. Abortando con error."
    exit 1
fi

echo "✅ Permisos corregidos correctamente."
