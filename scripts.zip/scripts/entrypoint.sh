#!/usr/bin/env bash
set -euo pipefail

cd "$(dirname "$0")"
SERVICE_DIR="$(pwd)"
MODELS_DIR="${HOME}/Modelos"

echo "🔹 Servicio iniciado desde: $SERVICE_DIR"
echo "🔸 Verificando entorno..."
echo "📅 Fecha: $(date)"

# Verifica si hay script principal
if [[ -f "app.py" ]]; then
  echo "🧠 Ejecutando app.py desde raíz..."
  exec python3 app.py

elif [[ -f "src/app.py" ]]; then
  echo "🧠 Ejecutando app.py desde src/"
  cd src && exec python3 app.py

else
  echo "❌ Error: No se encontró app.py en el servicio."
  echo "📁 Revisa que exista 'app.py' o 'src/app.py'."
  exit 1
fi
