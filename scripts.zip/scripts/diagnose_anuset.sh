#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")"

PROJECT_ROOT="$(pwd)"
SERVICES_DIR="$PROJECT_ROOT/services"
ENV_FILE="$PROJECT_ROOT/.env"

YELLOW='\033[1;33m'
GREEN='\033[1;32m'
RED='\033[1;31m'
RESET='\033[0m'

print_section() {
  echo -e "\n${YELLOW}🔍 $1${RESET}"
}

print_ok() {
  echo -e "${GREEN}✔ $1${RESET}"
}

print_error() {
  echo -e "${RED}✘ $1${RESET}"
}

print_section "Verificando dependencias básicas"

command -v docker >/dev/null 2>&1 && print_ok "Docker disponible" || print_error "Falta Docker"
command -v python3 >/dev/null 2>&1 && print_ok "Python3 disponible" || print_error "Falta Python3"

print_section "Verificando contenedores activos"
docker ps --format "🟢 {{.Names}} - {{.Status}}" || print_error "No se pudo ejecutar docker ps"

print_section "Verificando puertos expuestos"
docker ps --format "{{.Ports}}" | grep -Eo '[0-9]+->' | sed 's/->//g' | sort -n | uniq | while read -r port; do
  echo "🔌 Puerto: $port"
done

print_section "Verificando archivos esenciales"
[[ -f "$ENV_FILE" ]] && print_ok ".env presente" || print_error ".env faltante"
[[ -d "$SERVICES_DIR" ]] && print_ok "Carpeta de servicios presente" || print_error "Carpeta de servicios faltante"

print_section "Modelos presentes en ~/Modelos"
find ~/Modelos -type f \( -iname '*.bin' -o -iname '*.safetensors' \) -print 2>/dev/null || echo "Sin modelos encontrados."

print_section "Verificando scripts de IA"
for script in "$SERVICES_DIR"/*/app.py; do
  [ -f "$script" ] && echo "🧠 $script OK" || print_error "Falta app.py en $(dirname "$script")"
done

print_section "Revisión completa"
echo -e "${GREEN}✅ Diagnóstico finalizado.${RESET}"
echo -e "\n🔗 Verificando enlaces de modelos IA..."
bash scripts/enlazar_modelos.sh --check-installed

check_service() {
  local name="$1"
  if docker ps --format '{{.Names}}' | grep -q "$name"; then
    echo -e "✅ ${name} activo"
  else
    echo -e "❌ ${name} inactivo o no encontrado"
  fi
}

echo "[⏱️ MONITOREO BÁSICO DE SERVICIOS]"
for svc in backend frontend codellama musicgen xtts-es; do
  check_service "$svc"
done
