#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")/../frontend"
npm install vite@latest

