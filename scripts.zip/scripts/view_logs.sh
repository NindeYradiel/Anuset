#!/bin/bash
set -euo pipefail

LINES="${LINES:-7}"
FOLLOW="${1:-}"

echo "📜 Mostrando logs de los contenedores (últimas ${LINES} líneas)"
[ "$FOLLOW" == "--follow" ] && echo "🔁 Modo seguimiento activado"

# Función para colorear líneas según nivel de log
colorize_line() {
    local line="$1"
    if [[ "$line" == *"ERROR"* ]]; then
        echo -e "\033[0;31m$line\033[0m"  # Rojo
    elif [[ "$line" == *"WARNING"* ]]; then
        echo -e "\033[0;33m$line\033[0m"  # Amarillo
    elif [[ "$line" == *"INFO"* ]]; then
        echo -e "\033[0;36m$line\033[0m"  # Cian
    elif [[ "$line" == *"DEBUG"* ]]; then
        echo -e "\033[0;35m$line\033[0m"  # Magenta
    else
        echo "$line"
    fi
}

# Mostrar logs por contenedor
docker ps --format '{{.Names}}' | while read -r container; do
    echo -e "\n🔹 \033[1;34m$container\033[0m"

    if [ "$FOLLOW" == "--follow" ]; then
        docker logs -f "$container" 2>&1 | while read -r line; do
            colorize_line "$line"
        done
    else
        docker logs --tail "$LINES" "$container" 2>&1 | while read -r line; do
            colorize_line "$line"
        done
    fi
done

