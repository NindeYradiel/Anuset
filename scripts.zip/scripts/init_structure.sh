#!/bin/bash
set -euo pipefail

echo "🛠️ Creando estructura base de carpetas vacías con .gitkeep..."

mkdir -p backend/model-cache
mkdir -p backend/logs
mkdir -p frontend/dist
mkdir -p frontend/.vite
mkdir -p services
mkdir -p scripts
mkdir -p docker-volumes
mkdir -p model-cache

# Añadir .gitkeep a cada carpeta vacía
touch backend/model-cache/.gitkeep
touch backend/logs/.gitkeep
touch frontend/dist/.gitkeep
touch frontend/.vite/.gitkeep
touch services/.gitkeep
touch scripts/.gitkeep
touch docker-volumes/.gitkeep
touch model-cache/.gitkeep

echo "✅ Estructura inicial creada con .gitkeep"
