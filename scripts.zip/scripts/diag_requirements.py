#!/usr/bin/env python3
import os
from pathlib import Path
import argparse
from collections import defaultdict

try:
    import pkg_resources
except ImportError:
    pkg_resources = None

COLOR = {
    'OK': '\033[92m',
    'WARN': '\033[93m',
    'ERR': '\033[91m',
    'INFO': '\033[94m',
    'SKIP': '\033[95m',
    'END': '\033[0m'
}

def color(txt, lvl):
    return f"{COLOR.get(lvl, '')}{txt}{COLOR['END']}"

def leer_requirements(path):
    reqs = []
    try:
        with open(path) as f:
            for line in f:
                line = line.strip()
                if not line or line.startswith("#"):
                    continue
                reqs.append(line.lower())
        return reqs
    except Exception as e:
        print(color(f"  ⚠️ Error al leer {path}: {e}", "WARN"))
        return []

def es_servicio_python(carpeta):
    """Detecta si el servicio probablemente sea Python o debe omitirse"""
    if (carpeta / "package.json").exists() or (carpeta / "vite.config.ts").exists():
        return False
    return True

def analizar_reqs_por_servicio(services_path="services/"):
    servicios = {}
    base = Path(services_path)

    for carpeta in base.iterdir():
        if carpeta.is_dir():
            if not es_servicio_python(carpeta):
                servicios[carpeta.name] = "omitido"
                continue

            req_file = carpeta / "requirements.txt"
            if not req_file.exists():
                servicios[carpeta.name] = None  # No hay archivo
                continue

            reqs = leer_requirements(req_file)
            servicios[carpeta.name] = reqs
    return servicios

def detectar_duplicados(reqs):
    conteo = defaultdict(int)
    for r in reqs:
        nombre = r.split("==")[0]
        conteo[nombre] += 1
    return [k for k, v in conteo.items() if v > 1]

def verificar_instalacion(reqs):
    instalados = {pkg.key: pkg.version for pkg in pkg_resources.working_set}
    for r in reqs:
        if "==" in r:
            nombre, version = r.split("==")
        else:
            nombre, version = r, None

        estado = ""
        if nombre in instalados:
            if version and instalados[nombre] != version:
                estado = color(f"⚠️  {nombre} ({instalados[nombre]}) != requerido {version}", "WARN")
            else:
                estado = color(f"✔️  {nombre} ({instalados[nombre]})", "OK")
        else:
            estado = color(f"❌  {nombre} no instalado", "ERR")
        print(f"    {estado}")

def mostrar_lista_detallada(reqs):
    for r in reqs:
        if "==" in r:
            print(f"    {color('✔️', 'OK')} {r}")
        else:
            print(f"    {color('⚠️', 'WARN')} {r}  (sin versión)")

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--services", default="services/", help="Ruta base a servicios IA")
    parser.add_argument("--full", action="store_true", help="Mostrar detalles de dependencias")
    parser.add_argument("--check-installed", action="store_true", help="Verifica si los paquetes están instalados")
    args = parser.parse_args()

    if args.check_installed and not pkg_resources:
        print(color("❌ pkg_resources no disponible. Instala setuptools.", "ERR"))
        return

    print(color("🔎 Verificando requirements.txt por servicio IA...\n", "INFO"))
    resultados = analizar_reqs_por_servicio(args.services)

    resumen_total = {"ok": 0, "duplicados": 0, "vacios": 0, "faltantes": 0, "omitidos": 0}

    for servicio, reqs in sorted(resultados.items()):
        print(f"📁 Servicio: {color(servicio, 'INFO')}")
        if reqs == "omitido":
            print(color("  ⏩ Omitido (no es servicio Python)", "SKIP"))
            resumen_total["omitidos"] += 1
            continue
        if reqs is None:
            print(color("  ⚠️ requirements.txt no encontrado", "WARN"))
            resumen_total["faltantes"] += 1
            continue
        if not reqs:
            print(color("  ⚠️ requirements.txt vacío o inválido", "WARN"))
            resumen_total["vacios"] += 1
            continue

        if args.full:
            mostrar_lista_detallada(reqs)

        if args.check_installed:
            verificar_instalacion(reqs)

        dups = detectar_duplicados(reqs)
        if dups:
            print(color(f"  ❌ Duplicados encontrados: {', '.join(dups)}", "ERR"))
            resumen_total["duplicados"] += 1
        else:
            print(color("  ✅ Sin duplicados", "OK"))
            resumen_total["ok"] += 1

    print("\n📊 RESUMEN FINAL:")
    print(f"✅ OK: {color(str(resumen_total['ok']), 'OK')}")
    print(f"❌ Con duplicados: {color(str(resumen_total['duplicados']), 'ERR')}")
    print(f"⚠️ Vacíos o inválidos: {color(str(resumen_total['vacios'] + resumen_total['faltantes']), 'WARN')}")
    print(f"⏩ Omitidos (no Python): {color(str(resumen_total['omitidos']), 'SKIP')}")

if __name__ == "__main__":
    main()
