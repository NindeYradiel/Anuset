#!/bin/bash
# auto_backup.sh – Genera un snapshot de la estructura del proyecto Anuset89
set -euo pipefail

# Nombre del archivo de salida con fecha
OUTPUT="estructura_$(date +%Y%m%d).txt"

# Patrones a excluir
EXCLUDE="__pycache__|.git|.DS_Store|node_modules"

echo "📸 Generando snapshot estructural de Anuset..."
tree -a -L 3 -I "$EXCLUDE" > "$OUTPUT"

echo "✅ Snapshot guardado como $OUTPUT"
