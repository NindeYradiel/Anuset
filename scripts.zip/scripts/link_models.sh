#!/usr/bin/env bash
set -euo pipefail

# 📍 Carpeta origen de modelos
RESPALDO_DIR="$HOME/Respaldo/models"

# 📍 Carpeta base del proyecto
BASE_DIR="$(realpath "$(dirname "${BASH_SOURCE[0]}")/..")"
SERVICES_DIR="$BASE_DIR/services"

# 🧠 Tabla de modelos → servicio destino
declare -A MODELOS_SERVICIOS=(
  ["mm_sd_v15_v2.ckpt"]="animatediff"
  ["v3_sd15_mm.ckpt"]="animatediff"
  ["masterProFULLV4.safetensors"]="comfyui"
  ["rule-IL-V1.safetensors"]="comfyui"
  ["lol photos style.safetensors"]="comfyui"
  ["BUENO pro.safetensors"]="comfyui"
)

# 🎛️ Flags
FORCE=false
CHECK=false

# 🎛️ Parseo de argumentos
for arg in "$@"; do
  case "$arg" in
    --force) FORCE=true ;;
    --check-installed) CHECK=true ;;
  esac
done

# 📊 Contadores
total=0
enlazados=0
ya_existe=0
faltantes=0

# 🌀 Procesar todos los modelos en Respaldo
for modelo_path in "$RESPALDO_DIR"/*; do
  modelo="$(basename "$modelo_path")"
  ((total++))

  servicio="${MODELOS_SERVICIOS[$modelo]:-}"

  if [[ -z "$servicio" ]]; then
    echo "⚠️  Modelo no reconocido: '$modelo' (sin servicio asignado)"
    ((faltantes++))
    continue
  fi

  destino_dir="$SERVICES_DIR/$servicio/models"
  destino_link="$destino_dir/$modelo"

  mkdir -p "$destino_dir"

  if [[ "$CHECK" == true ]]; then
    if [[ -L "$destino_link" && -e "$destino_link" ]]; then
      echo "✅ Enlace ya activo: $modelo → $servicio"
    elif [[ -e "$destino_link" && ! -L "$destino_link" ]]; then
      echo "⚠️  Existe archivo real (no es enlace): $destino_link"
    else
      echo "❌ No enlazado: $modelo"
    fi
    continue
  fi

  # Forzar re-enlace
  if [[ "$FORCE" == true && -L "$destino_link" ]]; then
    rm -f "$destino_link"
  fi

  if [[ ! -e "$destino_link" ]]; then
    ln -s "$(realpath --relative-to="$destino_dir" "$modelo_path")" "$destino_link"
    echo "🔗 Enlazado: $modelo → $servicio"
    ((enlazados++))
  else
    echo "🟡 Ya existe: $modelo → $servicio"
    ((ya_existe++))
  fi
done

# 📈 Resumen
echo ""
echo "📦 Modelos procesados: $total"
echo "✅ Enlazados nuevos:   $enlazados"
echo "🟡 Ya enlazados:       $ya_existe"
echo "⚠️  Sin servicio:       $faltantes"
